VEILBOUND Android native title resources
Source: original approved rift background image and Emerald Whispers looping OGG.
These files require integration in Shipwright-Android Android title actor and audio system; copying to APK assets does not automatically enable playback.
Existing target branch: veilbound/test-lab; APK workflow .github/workflows/veilbound-android.yml.
